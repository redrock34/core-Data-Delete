//
//  ViewController.swift
//  photography
//
//  Created by John Zalubski on 8/13/19.
//  Copyright © 2019 John Zalubski. All rights reserved.
//

    import UIKit; import CoreData


    class ViewController: UIViewController,UICollectionViewDataSource, UICollectionViewDelegate {
    

    @IBOutlet var  block : UICollectionView!
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return users.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        var cell = block.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as? cell
        
        let title = users[indexPath.row]
        let attr5 = title.value(forKey: "atBATS") as? String
        let text = [attr5,""].flatMap { $0 }.reduce("", +)
        cell?.name?.text = "\(text)"
        
        
        cell?.index = indexPath
        cell?.delegateA = self
        return cell!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        users = AppDelegate.cdHandler.fetchObject()
        block.reloadData()

    }



    }

    var users = [Item]()
    class cell: UICollectionViewCell {
        var delegateA: datacollectionProfotocol?
        var index : IndexPath?
        @IBOutlet var name : UILabel!
        @IBAction func show() {
        
        }
        @IBAction func delete() {
           delegateA?.deleteData(indx: (index?.row)!)
            print("cnn")
        }
    }



    protocol datacollectionProfotocol {
    
    func deleteData(indx:Int)
    }
    extension ViewController : datacollectionProfotocol {
    func deleteData(indx: Int) {
        users.remove(at: indx)
        block.reloadData()
        let date = users[indx]
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Item")
        
        request.predicate = NSPredicate(format:"atBATS = %@", date as CVarArg)
        
        let result = try? context.fetch(request)
        let resultData = result as! [NSManagedObject]
        
        for object in resultData {
            context.delete(object)
        }
        
        do {
            try context.save()
            print(" saved!")
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }

    }
    
    }
    

 
    class gab : UIViewController {
    @IBOutlet var sam : UITextField!
    @IBAction func press(_ sender: Any) {
         saver()
    }
    
    func saver() {
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Item", in: managedContext)!
        let item = NSManagedObject(entity: entity, insertInto: managedContext)
        let fetch = NSFetchRequest<NSFetchRequestResult>(entityName: "Item")
        
        
        
        
        item.setValue(sam.text, forKey: "atBATS")
        
        do {
            let result = try? managedContext.fetch(fetch) as? [Item]
            print("Queen",result?.count)
            try? managedContext.save()
            
            print("Text = \(sam.text)")
            
        }
        catch {
            print("Could not save")
        }
        
    }
    }

